# Jenkins-Nexus-SonarQube-Setup
# NEXUS INSTALLATION STEPS & Proxy set up:
# https://help.sonatype.com/repomanager3/planning-your-implementation/quick-start-guide---proxying-maven-and-npm


#Ansible-Tower:
https://docs.ansible.com/ansible-tower/
