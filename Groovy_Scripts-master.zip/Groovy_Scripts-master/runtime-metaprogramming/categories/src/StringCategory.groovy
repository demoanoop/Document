class StringCategory {

    static String shout(String str){
        str.toUpperCase()
    }

}
