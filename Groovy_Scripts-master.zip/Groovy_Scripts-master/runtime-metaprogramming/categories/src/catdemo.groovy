//String.metaClass.shout = { -> toUpperCase() }
//println "Hello, World!".shout()


use(StringCategory) {
    println "Hello,World!".shout()
}

println "Hello,World!".shout()
