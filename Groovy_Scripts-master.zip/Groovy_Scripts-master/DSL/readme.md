Domain Specific Languages (DSLs)
