package java;

public class RunnableDemo implements Runnable {

    public RunnableDemo(){
        // do stuff
    }

    @Override
    public void run() {
        // this is where our task would go
    }

}
