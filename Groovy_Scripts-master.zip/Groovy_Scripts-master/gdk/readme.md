Working with the GDK
