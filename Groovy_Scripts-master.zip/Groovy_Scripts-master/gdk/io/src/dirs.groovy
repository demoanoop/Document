
// list all the directories in a given path
//String dir = '/Users/vega/dev/groovy/apache-groovy-course'
//List hidden = []
//new File(dir).eachFile { file ->
//
//    if( file.isDirectory() ){
//        println file.name
//    }
//
//    if( file.isHidden() ) {
//        hidden << file.name
//    }
//
//}
//
//println hidden
//
//
//String groovyCourse = '/Users/vega/dev/groovy/apache-groovy-course'
//new File(groovyCourse).eachDir { subfolder ->
//    println subfolder
//}


//def groovyCourseDir = new File('/Users/vega/dev/groovy/apache-groovy-course')
//println groovyCourseDir.directorySize()


// create a new directory
// new File('dummy').mkdir()


// create a bunch of directories
// new File('one/two/three').mkdirs()


//new File('dummy').deleteDir()