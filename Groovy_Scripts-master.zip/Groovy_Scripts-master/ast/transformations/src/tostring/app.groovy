package tostring

Person p = new Person(first:"Dan",last: "Vega", email: "danvega@gmail.com")

println p.toString()
