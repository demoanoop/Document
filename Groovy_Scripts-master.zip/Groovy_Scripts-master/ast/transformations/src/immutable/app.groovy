package immutable

Person p = new Person(first: "Dan",last: "Vega")
println p.toString()

p.first = "Andy"