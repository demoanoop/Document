package canonical

Person p1 = new Person("Dan","Vega","danvega@gmail.com")
Person p2 = new Person("Dan","Vega","danvega@gmail.com")

assert p1 == p2
println p1.toString()