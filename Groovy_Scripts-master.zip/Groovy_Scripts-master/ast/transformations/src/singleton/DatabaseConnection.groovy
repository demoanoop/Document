package singleton

@Singleton
class DatabaseConnection {



}
