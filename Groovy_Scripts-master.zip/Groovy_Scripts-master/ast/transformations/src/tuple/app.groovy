package tuple

Person p = new Person("Dan","Vega","danvega@gmail.com")
println p.toString()