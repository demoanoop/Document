package com.therealdanvega

import groovy.transform.ToString

@ToString
class Person {

    String first
    String last
    String email
    Date dob

}
