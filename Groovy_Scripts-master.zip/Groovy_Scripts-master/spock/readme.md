Testing with the Spock Framework
