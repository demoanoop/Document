#!/usr/bin/env groovy
println "Hello from the shebang line"