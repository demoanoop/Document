// Spring MVC Controller

@Controller
class HomeController {


    String home() {
    
    }

}