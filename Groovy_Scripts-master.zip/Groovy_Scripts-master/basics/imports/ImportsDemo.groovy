import groovy.xml.*

def xml = new MarkupBuilder()