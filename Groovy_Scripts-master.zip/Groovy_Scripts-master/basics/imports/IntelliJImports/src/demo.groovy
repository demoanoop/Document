import groovy.xml.MarkupBuilder

def xml = new MarkupBuilder()
