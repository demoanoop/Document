// a script is any groovy code not enclosed in a class file
// but don't make the mistake thinking there is no class
println "Hello from myscript.groovy"