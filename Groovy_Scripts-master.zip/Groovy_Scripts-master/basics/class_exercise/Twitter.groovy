def tweet = new Tweet("therealdanvega","Hello, Twitter!")
tweet.addToFavorites()
println tweet