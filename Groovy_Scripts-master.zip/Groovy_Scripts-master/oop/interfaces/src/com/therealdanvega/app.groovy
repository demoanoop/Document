package com.therealdanvega

import com.therealdanvega.service.PersonService

PersonService personService = new PersonService()

println personService.find()
