package com.therealdanvega.domain

@groovy.transform.ToString
class Person {

    String first,last

}
