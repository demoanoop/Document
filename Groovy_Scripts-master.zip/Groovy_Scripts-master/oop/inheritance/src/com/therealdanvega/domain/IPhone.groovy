package com.therealdanvega.domain

@groovy.transform.ToString()
class IPhone extends Phone {

    String iosVersion

    def homeButtonPressed(){

    }

    def airPlay(){

    }

    def powerOn(){

    }


}
