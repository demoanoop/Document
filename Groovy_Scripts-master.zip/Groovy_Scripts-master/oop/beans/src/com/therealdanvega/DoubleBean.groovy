package com.therealdanvega

class DoubleBean {

    public Integer value

    void setValue(value){
        this.value = value
    }

    Integer getValue(){
        value * 2
    }
}
