package com.therealdanvega.traits

trait SpeakingAbility {

    public String a
    private String b

    String speak(){
        "I'm Speaking!"
    }

}