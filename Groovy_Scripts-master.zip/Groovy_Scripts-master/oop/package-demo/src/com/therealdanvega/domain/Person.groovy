package com.therealdanvega.domain

class Person {
}
