def x = 10
x.getClass().getName()

x = "Dan" 
x.getClass().getName()

Integer y = 10
