byte b = 10
b.getClass().getName()

short s = 1000
s.getClass().getName()

int i = 10000
i.getClass().getName()

long l = 100
l.getClass().getName()

float f = 1.25
f.getClass().getName()

double d = 5.25
d.getClass().getName()

char c = 'c'
c.getClass().getName()

boolean bool = true
bool.getClass().getName()


32342323424324324444444444.class

4.50.class