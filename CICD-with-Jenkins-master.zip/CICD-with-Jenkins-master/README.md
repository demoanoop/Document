# Jenkins - Maven - JUnit - Checkstyle - SonarQube - Nexus - Docker - ECR - Ansible - EKS
# Master Slave Architecture


#### Delete EKS Cluster
# https://docs.aws.amazon.com/eks/latest/userguide/delete-cluster.html
